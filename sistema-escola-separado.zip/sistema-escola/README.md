# 🎓 Sistema de Gestão de Pessoas — Instituição de Ensino

## Estrutura do Projeto

```
sistema-escola/
└── src/
    ├── App.jsx                   ← Main: componente raiz + lógica da UI
    ├── models/
    │   ├── Autenticavel.js       ← Interface Autenticavel (contrato login)
    │   ├── Pessoa.js             ← Classe abstrata Pessoa (#nome, #cpf)
    │   ├── Aluno.js              ← Herda Pessoa + implementa Autenticavel
    │   ├── Professor.js          ← Herda Pessoa + implementa Autenticavel
    │   └── Secretaria.js         ← CRUD de pessoas (cadastrar/remover/listar)
    └── components/
        └── UI.jsx                ← Componentes visuais reutilizáveis (Badge, Card, etc.)
```

## Hierarquia de Classes

```
Autenticavel (interface)
    └── login(): string

Pessoa (abstrata)
    ├── #nome: string  [privado]
    ├── #cpf: string   [privado]
    ├── getNome() / setNome()
    ├── getCpf()  / setCpf()
    ├── mostrarDados()  ← abstrato
    └── login()         ← abstrato (Autenticavel)

Aluno extends Pessoa
    ├── #curso: string
    ├── #periodo: int
    ├── mostrarDados() → "Aluno | Nome | CPF | Curso | Período"
    └── login()        → "Aluno X acessou... X está estudando."

Professor extends Pessoa
    ├── #disciplina: string
    ├── #titulacao: string
    ├── mostrarDados() → "Professor | Nome | Disciplina | Titulação"
    └── login()        → "Professor X acessou... X está dando aula."

Secretaria
    ├── #pessoas: Pessoa[]
    ├── cadastrar(pessoa)
    ├── remover(cpf)
    ├── buscarPorCpf(cpf)
    ├── listarTodos()
    ├── listarAlunos()
    └── listarProfessores()
```

## Como usar no VS Code

1. Abra a pasta `sistema-escola/` no VS Code
2. Instale as dependências: `npm install`
3. Rode o projeto: `npm run dev`

> Projeto criado com React + Vite.
